import os
import json
from flask import Flask, render_template, request, redirect, url_for, session, jsonify

app = Flask(__name__)
app.secret_key = os.urandom(24)

USERS_FILE = 'users.json'

def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE, 'r') as file:
        return json.load(file)

def save_users(users):
    with open(USERS_FILE, 'w') as file:
        json.dump(users, file, indent=4)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        users = load_users()
        
        if username in users:
            return jsonify({"message": "Benutzername existiert bereits"}), 400
        
        users[username] = {"password": password}
        save_users(users)
        return jsonify({"message": "Registrierung erfolgreich"}), 201
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        users = load_users()
        
        if username in users and users[username]['password'] == password:
            session['username'] = username
            return redirect(url_for('personal_page', username=username))
        
        return jsonify({"message": "Ungültige Anmeldedaten"}), 400
    
    return render_template('login.html')

@app.route('/<username>', methods=['GET', 'POST'])
def personal_page(username):
    if 'username' not in session or session['username'] != username:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        old_password = request.form['old_password']
        new_password = request.form['new_password']
        
        users = load_users()
        
        if users[username]['password'] == old_password:
            users[username]['password'] = new_password
            save_users(users)
            return render_template('password_changed.html')
        else:
            return render_template('personal_page.html', username=username, error="Fehler: Falsches Passwort.")
    
    return render_template('personal_page.html', username=username)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return render_template('logout.html')

if __name__ == '__main__':
    app.run(debug=True)
