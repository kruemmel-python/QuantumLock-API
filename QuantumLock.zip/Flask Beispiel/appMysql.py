import os
import mysql.connector
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.urandom(24)

# MySQL-Datenbankkonfiguration
DB_HOST = 'localhost'
DB_USER = 'root'
DB_PASSWORD = '1234'
DB_NAME = 'quantumlock'

def get_db_connection():
    connection = mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )
    return connection

def create_users_table():
    connection = get_db_connection()
    cursor = connection.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(255) UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
    ''')
    connection.commit()
    cursor.close()
    connection.close()

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        connection = get_db_connection()
        cursor = connection.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        
        if user:
            cursor.close()
            connection.close()
            return jsonify({"message": "Benutzername existiert bereits"}), 400
        
        password_hash = generate_password_hash(password)
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (%s, %s)', (username, password_hash))
        connection.commit()
        
        cursor.close()
        connection.close()
        
        return jsonify({"message": "Registrierung erfolgreich"}), 201
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        connection = get_db_connection()
        cursor = connection.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        
        cursor.close()
        connection.close()
        
        if user and check_password_hash(user[2], password):
            session['username'] = username
            return redirect(url_for('personal_page', username=username))
        
        return jsonify({"message": "Ungültige Anmeldedaten"}), 400
    
    return render_template('login.html')

@app.route('/<username>', methods=['GET', 'POST'])
def personal_page(username):
    if 'username' not in session or session['username'] != username:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        old_password = request.form['old_password']
        new_password = request.form['new_password']
        
        connection = get_db_connection()
        cursor = connection.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        
        if user and check_password_hash(user[2], old_password):
            new_password_hash = generate_password_hash(new_password)
            cursor.execute('UPDATE users SET password_hash = %s WHERE username = %s', (new_password_hash, username))
            connection.commit()
            cursor.close()
            connection.close()
            return render_template('password_changed.html')
        else:
            cursor.close()
            connection.close()
            return render_template('personal_page.html', username=username, error="Fehler: Falsches Passwort.")
    
    return render_template('personal_page.html', username=username)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return render_template('logout.html')

if __name__ == '__main__':
    create_users_table()
    app.run(debug=True)
