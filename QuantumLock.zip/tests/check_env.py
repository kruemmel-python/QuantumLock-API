import os
from dotenv import load_dotenv

# Lade die Umgebungsvariablen aus der .env-Datei
load_dotenv()

# Überprüfe, ob die Umgebungsvariablen geladen wurden
print("STORAGE_PASSWORD:", os.getenv('STORAGE_PASSWORD'))

# Wenn die Variable nicht geladen ist, gebe eine Warnung aus
if not os.getenv('STORAGE_PASSWORD'):
    print("Warnung: STORAGE_PASSWORD ist nicht gesetzt")
