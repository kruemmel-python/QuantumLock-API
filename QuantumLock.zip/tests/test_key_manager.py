import os
import unittest
from dotenv import load_dotenv

# Lade die Umgebungsvariablen aus der .env-Datei
load_dotenv(dotenv_path='C:/Users/ralfk/Desktop/CHAOSVERSCHLUESSELUNG/my_api_package/QuantumLock/.env')

# Überprüfe, ob die Umgebungsvariablen geladen wurden
print("STORAGE_PASSWORD:", os.getenv('STORAGE_PASSWORD'))

if not os.getenv('STORAGE_PASSWORD'):
    raise EnvironmentError("Die Umgebungsvariable 'STORAGE_PASSWORD' muss gesetzt sein.")

print("Umgebungsvariablen erfolgreich geladen")

from QuantumLock import KeyManager, EncryptionError, DecryptionError

print("Module erfolgreich importiert")

class TestKeyManager(unittest.TestCase):
    
    def setUp(self):
        print("setUp gestartet")
        missing_vars = [var for var in ['STORAGE_PASSWORD', 'STORAGE_SALT', 'LOG_ENCRYPTION_KEY'] if not os.getenv(var)]
        if missing_vars:
            raise EnvironmentError(f"Fehlende Umgebungsvariablen: {', '.join(missing_vars)}")
        
        # Verwende eine JSON-Datei zur Speicherung, um die Datenbank zu vermeiden
        self.key_manager = KeyManager(salt_size=16, key_length=32, storage_path="test_keys.json")
        print("KeyManager erfolgreich initialisiert")
    
    def tearDown(self):
        print("tearDown gestartet")
        if os.path.exists("test_keys.json"):
            os.remove("test_keys.json")
        print("tearDown abgeschlossen")
    
    def test_add_and_authenticate_user(self):
        print("test_add_and_authenticate_user gestartet")
        
        print("Füge Benutzer hinzu...")
        self.key_manager.add_user("testuser", "testpassword")
        print("Benutzer hinzugefügt")
        
        print("Authentifiziere Benutzer...")
        authenticated = self.key_manager.authenticate_user("testuser", "testpassword")
        print(f"Authentifizierung erfolgreich: {authenticated}")
        self.assertTrue(authenticated)
        
        print("Überprüfe falsches Passwort...")
        wrong_auth = self.key_manager.authenticate_user("testuser", "wrongpassword")
        print(f"Falsches Passwort authentifiziert: {wrong_auth}")
        self.assertFalse(wrong_auth)
        
        print("test_add_and_authenticate_user abgeschlossen")
    
    def test_encrypt_and_decrypt(self):
        print("test_encrypt_and_decrypt gestartet")
        plaintext = b"Test message"
        aad = b"Test AAD"
        
        print("Verschlüssele Nachricht...")
        encrypted_data = self.key_manager._hybrid_encrypt(plaintext, aad)
        print(f"Verschlüsselte Daten: {encrypted_data}")
        
        print("Entschlüssele Nachricht...")
        decrypted_data = self.key_manager._hybrid_decrypt(encrypted_data, aad)
        print(f"Entschlüsselte Nachricht: {decrypted_data}")
        
        self.assertEqual(decrypted_data, plaintext)
        print("test_encrypt_and_decrypt abgeschlossen")
    
    def test_encryption_error(self):
        print("test_encryption_error gestartet")
        with self.assertRaises(EncryptionError):
            print("Versuche leere Daten zu verschlüsseln...")
            self.key_manager._hybrid_encrypt(b"", b"")
        print("test_encryption_error abgeschlossen")

if __name__ == "__main__":
    unittest.main()
