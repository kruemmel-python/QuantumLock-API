import mysql.connector
from mysql.connector import Error

try:
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='1234',
        database='QuantumLock'
    )

    if connection.is_connected():
        print("Verbindung zur MySQL-Datenbank erfolgreich.")
        db_info = connection.get_server_info()
        print("MySQL Server Version:", db_info)
        cursor = connection.cursor()
        cursor.execute("SELECT DATABASE();")
        record = cursor.fetchone()
        print("Angeschlossene Datenbank:", record)

except Error as e:
    print("Fehler bei der Verbindung zur MySQL-Datenbank:", e)

finally:
    if connection.is_connected():
        cursor.close()
        connection.close()
        print("MySQL-Verbindung geschlossen.")
