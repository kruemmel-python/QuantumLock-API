import os
from dotenv import load_dotenv
import base64
import json
import logging
import secrets
import mysql.connector
from mysql.connector import Error as MySQLError, InterfaceError, OperationalError, ProgrammingError
from datetime import datetime, timezone, timedelta
from typing import Tuple, Dict, Optional
from collections import deque
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import bcrypt
import threading

# Lade die Umgebungsvariablen aus der .env-Datei
load_dotenv()

# Überprüfung der Pflicht-Umgebungsvariablen beim Start
required_env_vars = ['STORAGE_PASSWORD', 'STORAGE_SALT', 'LOG_ENCRYPTION_KEY', 'DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_NAME']
for var in required_env_vars:
    if var not in os.environ:
        raise EnvironmentError(f"Die Umgebungsvariable '{var}' muss gesetzt sein.")

# Verschlüsselung der Protokolldateien
LOG_ENCRYPTION_KEY = os.getenv('LOG_ENCRYPTION_KEY').encode()

class EncryptionError(Exception):
    """Benutzerdefinierte Ausnahme für Verschlüsselungsfehler."""
    pass

class DecryptionError(Exception):
    """Benutzerdefinierte Ausnahme für Entschlüsselungsfehler."""
    pass

class DatabaseError(Exception):
    """Benutzerdefinierte Ausnahme für Datenbankfehler."""
    pass

def encrypt_log_message(message: str) -> str:
    """
    Verschlüsselt eine Log-Nachricht mit AES-GCM und kodiert sie in Base64.
    
    Args:
        message (str): Die zu verschlüsselnde Nachricht.

    Returns:
        str: Die verschlüsselte und kodierte Nachricht.

    Raises:
        EncryptionError: Bei Fehlern während der Verschlüsselung.
    """
    try:
        aesgcm = AESGCM(LOG_ENCRYPTION_KEY)
        nonce = secrets.token_bytes(12)
        ciphertext = aesgcm.encrypt(nonce, message.encode(), None)
        return base64.b64encode(nonce + ciphertext).decode()
    except Exception as e:
        logging.error(f"Fehler bei der Verschlüsselung der Log-Nachricht: {e}")
        raise EncryptionError("Verschlüsselung der Log-Nachricht fehlgeschlagen.") from e

class EncryptedLogHandler(logging.Handler):
    """
    Ein benutzerdefinierter Logging-Handler, der Log-Nachrichten verschlüsselt,
    bevor sie in eine Datei geschrieben werden.
    """
    def emit(self, record):
        """
        Überschreibt die `emit` Methode von `logging.Handler` zur Verschlüsselung und Speicherung von Logs.
        """
        try:
            log_entry = self.format(record)
            if any(sensitive_word in log_entry.lower() for sensitive_word in ['password', 'secret']):
                log_entry = 'Sensitive data omitted.'
            encrypted_log_entry = encrypt_log_message(log_entry)
            with open('key_manager_encrypted.log', 'a') as log_file:
                log_file.write(encrypted_log_entry + '\n')
        except EncryptionError as e:
            logging.error(f"Fehler beim Verschlüsseln des Log-Eintrags: {e}")

# Konfiguration des verschlüsselten Loggings
logger = logging.getLogger()
logger.setLevel(logging.INFO)
handler = EncryptedLogHandler()
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

class ReplayProtection:
    """
    Klasse zum Schutz vor Wiederholungsangriffen durch Überprüfung von Nonces und Zeitstempeln.
    """
    def __init__(self):
        """
        Initialisiert die ReplayProtection-Klasse mit einem deque für Nonces und einem Zeitfenster.
        """
        self.used_nonces = deque(maxlen=1000)
        self.time_window = timedelta(minutes=5)
        self.lock = threading.Lock()

    def generate_nonce(self) -> str:
        """
        Generiert einen einzigartigen Nonce-Wert als Base64-kodierter String.

        Returns:
            str: Der generierte Nonce-Wert als Base64-kodierter String.
        """
        return base64.urlsafe_b64encode(secrets.token_bytes(16)).decode()

    def validate_nonce(self, nonce: str) -> bool:
        """
        Überprüft, ob ein Nonce gültig ist.

        Args:
            nonce (str): Der zu überprüfende Nonce.

        Returns:
            bool: True, wenn der Nonce gültig ist, andernfalls False.
        """
        now = datetime.now(timezone.utc)
        with self.lock:
            while self.used_nonces and self.used_nonces[0][1] < now - self.time_window:
                self.used_nonces.popleft()
            
            if nonce in (n[0] for n in self.used_nonces):
                logging.warning(f"Ungültiger oder wiederverwendeter Nonce entdeckt: {nonce}")
                return False
            
            self.used_nonces.append((nonce, now))
        return True

    def validate_timestamp(self, timestamp: datetime) -> bool:
        """
        Überprüft, ob der Zeitstempel innerhalb des akzeptablen Fensters liegt.

        Args:
            timestamp (datetime): Der zu überprüfende Zeitstempel.

        Returns:
            bool: True, wenn der Zeitstempel innerhalb des Fensters liegt, andernfalls False.
        """
        now = datetime.now(timezone.utc)
        if abs(now - timestamp) > self.time_window:
            logging.warning(f"Zeitstempel außerhalb des gültigen Fensters: {timestamp}")
            return False
        return True

replay_protection = ReplayProtection()

class KeyManager:
    """
    Klasse zur Verwaltung von Schlüsseln, einschließlich Verschlüsselung, Speicherung und Rotation.
    """
    RATE_LIMIT_THRESHOLD = 5
    RATE_LIMIT_PERIOD = timedelta(minutes=15)
    GLOBAL_RATE_LIMIT_THRESHOLD = 100
    GLOBAL_RATE_LIMIT_PERIOD = timedelta(minutes=15)
    AES_KEY_SIZE = 32

    def __init__(self, salt_size: int = 16, key_length: int = AES_KEY_SIZE, storage_path: Optional[str] = None, rotation_interval: int = 86400):
        """
        Initialisiert den KeyManager mit sicherer Passwortverwaltung.

        Args:
            salt_size (int): Größe des Salts in Bytes.
            key_length (int): Länge des Schlüssels in Bytes.
            storage_path (Optional[str]): Pfad zur JSON-Datei für die Speicherung von Schlüsseln.
            rotation_interval (int): Intervall für die Rotation von Schlüsseln in Sekunden.
        """
        self.salt_size = salt_size
        self.key_length = key_length
        self.storage_path = storage_path
        self.rotation_interval = rotation_interval
        self.use_mysql = False if storage_path else True
        self.lock = threading.Lock()  # Hier wird das Lock-Attribut korrekt initialisiert
        self.keys = self._load_keys()

    def _load_keys(self) -> Dict[str, str]:
        logging.debug("Beginne mit dem Laden der Schlüssel aus der Datenbank.")
        with self.lock:
            if self.use_mysql:
                try:
                    connection = self._get_db_connection()
                    logging.debug("Verbindung zur Datenbank hergestellt.")
                    cursor = connection.cursor(dictionary=True)
                    cursor.execute("SELECT * FROM keys")
                    keys = {row['key_name']: row['key_value'] for row in cursor.fetchall()}
                    logging.debug(f"Schlüssel erfolgreich geladen: {keys}")
                    cursor.close()
                    connection.close()
                    return keys
                except MySQLError as e:
                    logging.error(f"Fehler beim Laden der Schlüssel aus der Datenbank: {e}")
                    raise DatabaseError("Fehler beim Laden der Schlüssel aus der Datenbank.") from e
            else:
                if not self.storage_path or not os.path.isfile(self.storage_path):
                    return {}
                with open(self.storage_path, 'r') as file:
                    keys = json.load(file)
                    logging.debug(f"Schlüssel erfolgreich aus Datei geladen: {keys}")
                    return keys


    def _save_keys(self) -> None:
        """
        Speichert die aktuellen Schlüssel in der JSON-Datei oder MySQL-Datenbank.
        """
        with self.lock:
            if self.use_mysql:
                try:
                    connection = self._get_db_connection()
                    cursor = connection.cursor()
                    cursor.execute("DELETE FROM keys")  # Löscht alle vorhandenen Schlüssel, um Platz für neue zu schaffen
                    for key, value in self.keys.items():
                        cursor.execute("INSERT INTO keys (key_name, key_value) VALUES (%s, %s)", (key, value))
                    connection.commit()
                    cursor.close()
                    connection.close()
                except InterfaceError as e:
                    logging.error(f"Netzwerkfehler bei der Speicherung in der Datenbank: {e}")
                    raise DatabaseError("Netzwerkfehler bei der Speicherung in der Datenbank.") from e
                except OperationalError as e:
                    logging.error(f"Betriebsfehler bei der Speicherung in der Datenbank: {e}")
                    raise DatabaseError("Betriebsfehler bei der Speicherung in der Datenbank.") from e
                except ProgrammingError as e:
                    logging.error(f"Programmfehler bei der Speicherung in der Datenbank: {e}")
                    raise DatabaseError("Programmfehler bei der Speicherung in der Datenbank.") from e
                except MySQLError as e:
                    logging.error(f"Allgemeiner Fehler bei der Speicherung in der Datenbank: {e}")
                    raise DatabaseError("Allgemeiner Fehler bei der Speicherung in der Datenbank.") from e
            else:
                with open(self.storage_path, 'w') as file:
                    json.dump(self.keys, file, indent=4)

    def _get_db_connection(self):
        """
        Stellt eine Verbindung zur MySQL-Datenbank her, wobei SSL/TLS verwendet wird.

        Returns:
            mysql.connector.connection_cext.CMySQLConnection: Die Datenbankverbindung.
        """
        try:
            return mysql.connector.connect(
                host=os.getenv('DB_HOST'),
                user=os.getenv('DB_USER'),
                password=os.getenv('DB_PASSWORD'),
                database=os.getenv('DB_NAME'),
                ssl_ca=os.getenv('DB_SSL_CA'),
                ssl_cert=os.getenv('DB_SSL_CERT'),
                ssl_key=os.getenv('DB_SSL_KEY')
            )
        except MySQLError as e:
            logging.error(f"Fehler bei der Verbindung zur Datenbank: {e}")
            raise DatabaseError("Fehler bei der Verbindung zur Datenbank.") from e

    def _generate_salt(self) -> bytes:
        """
        Generiert ein zufälliges Salt für die Passwort-Hardening-Prozesse.

        Returns:
            bytes: Das generierte Salt.
        """
        return secrets.token_bytes(self.salt_size)

    def _hash_password(self, password: str, salt: bytes) -> str:
        """
        Hashing des Passworts mit einem Salt unter Verwendung von bcrypt.

        Args:
            password (str): Das zu hashende Passwort.
            salt (bytes): Das Salt für den Hashing-Prozess.

        Returns:
            str: Der generierte Passwort-Hash.
        """
        return bcrypt.hashpw(password.encode(), bcrypt.gensalt(rounds=12)).decode()

    def _rotate_keys(self) -> None:
        """
        Führt die Rotation der AES-Schlüssel durch.
        """
        try:
            now = datetime.now(timezone.utc)
            new_key = secrets.token_bytes(self.key_length)
            with self.lock:
                self.keys['aes_key'] = base64.b64encode(new_key).decode()
                self._save_keys()
            logging.info(f"Schlüssel rotiert am {now}")
        except Exception as e:
            logging.error(f"Fehler bei der Schlüsselrotation: {e}")
            raise EncryptionError("Fehler bei der Schlüsselrotation.") from e

    def _hybrid_encrypt(self, plaintext: bytes, aad: bytes) -> bytes:
        """
        Verschlüsselt Daten mit AES-GCM.

        Args:
            plaintext (bytes): Die zu verschlüsselnden Daten.
            aad (bytes): Zusätzliche Authentifizierungsdaten (AAD).

        Returns:
            bytes: Die verschlüsselten Daten.

        Raises:
            EncryptionError: Bei Fehlern während der Verschlüsselung.
        """
        try:
            aes_key = base64.b64decode(self.keys['aes_key'])
            aesgcm = AESGCM(aes_key)
            nonce = secrets.token_bytes(12)
            ciphertext = aesgcm.encrypt(nonce, plaintext, aad)
            return nonce + ciphertext
        except Exception as e:
            logging.error(f"Fehler bei der Verschlüsselung: {e}")
            raise EncryptionError("Verschlüsselung fehlgeschlagen.") from e

    def _hybrid_decrypt(self, encrypted_data: bytes, aad: bytes) -> bytes:
        """
        Entschlüsselt Daten mit AES-GCM.

        Args:
            encrypted_data (bytes): Die zu entschlüsselnden Daten.
            aad (bytes): Zusätzliche Authentifizierungsdaten (AAD).

        Returns:
            bytes: Die entschlüsselten Daten.

        Raises:
            DecryptionError: Bei Fehlern während der Entschlüsselung.
        """
        try:
            aes_key = base64.b64decode(self.keys['aes_key'])
            aesgcm = AESGCM(aes_key)
            nonce = encrypted_data[:12]
            ciphertext = encrypted_data[12:]
            plaintext = aesgcm.decrypt(nonce, ciphertext, aad)
            return plaintext
        except Exception as e:
            logging.error(f"Fehler bei der Entschlüsselung: {e}")
            raise DecryptionError("Entschlüsselung fehlgeschlagen.") from e

    def add_user(self, username: str, password: str) -> None:
        """
        Fügt einen neuen Benutzer hinzu, indem ein Passwort gehasht und gespeichert wird.

        Args:
            username (str): Der Name des neuen Benutzers.
            password (str): Das Passwort des neuen Benutzers.

        Raises:
            ValueError: Wenn der Benutzername bereits existiert.
        """
        with self.lock:
            if username in self.keys.get('users', {}):
                raise ValueError(f"Benutzername '{username}' existiert bereits.")
            salt = self._generate_salt()
            hashed_password = self._hash_password(password, salt)
            self.keys.setdefault('users', {})[username] = {
                'password': hashed_password,
                'salt': base64.b64encode(salt).decode()
            }
            self._save_keys()

    def authenticate_user(self, username: str, password: str) -> bool:
        """
        Authentifiziert einen Benutzer, indem das Passwort überprüft wird.

        Args:
            username (str): Der Name des Benutzers.
            password (str): Das Passwort des Benutzers.

        Returns:
            bool: True, wenn die Authentifizierung erfolgreich ist, andernfalls False.
        """
        with self.lock:
            user = self.keys.get('users', {}).get(username)
            if not user:
                return False
            salt = base64.b64decode(user['salt'])
            hashed_password = self._hash_password(password, salt)
            return hashed_password == user['password']

    def rate_limit_check(self, user_id: str) -> bool:
        """
        Überprüft, ob ein Benutzer die Rate-Limiting-Grenze überschritten hat.

        Args:
            user_id (str): Die ID des Benutzers.

        Returns:
            bool: True, wenn die Rate-Limiting-Grenze überschritten wurde, andernfalls False.
        """
        now = datetime.now(timezone.utc)
        with self.lock:
            user_attempts = self.keys.get('rate_limits', {}).get(user_id, [])
            user_attempts = [attempt for attempt in user_attempts if now - attempt < self.RATE_LIMIT_PERIOD]
            if len(user_attempts) >= self.RATE_LIMIT_THRESHOLD:
                logging.warning(f"Rate-Limiting-Grenze für Benutzer '{user_id}' überschritten.")
                return True
            self.keys.setdefault('rate_limits', {})[user_id] = user_attempts + [now]
            self._save_keys()
        return False

    def global_rate_limit_check(self, ip_address: str) -> bool:
        """
        Überprüft, ob eine IP-Adresse die globale Rate-Limiting-Grenze überschritten hat.

        Args:
            ip_address (str): Die IP-Adresse des Benutzers.

        Returns:
            bool: True, wenn die Rate-Limiting-Grenze überschritten wurde, andernfalls False.
        """
        now = datetime.now(timezone.utc)
        with self.lock:
            ip_attempts = self.keys.get('global_rate_limits', {}).get(ip_address, [])
            ip_attempts = [attempt for attempt in ip_attempts if now - attempt < self.GLOBAL_RATE_LIMIT_PERIOD]
            if len(ip_attempts) >= self.GLOBAL_RATE_LIMIT_THRESHOLD:
                logging.warning(f"Globale Rate-Limiting-Grenze für IP-Adresse '{ip_address}' überschritten.")
                return True
            self.keys.setdefault('global_rate_limits', {})[ip_address] = ip_attempts + [now]
            self._save_keys()
        return False



# Beispiel für die Nutzung der KeyManager-Klasse
if __name__ == "__main__":
    key_manager = KeyManager()
    
    key_manager._rotate_keys()

    key_manager.add_user('testuser', 'testpassword')

    authenticated = key_manager.authenticate_user('testuser', 'testpassword')
    print(f"Benutzer authentifiziert: {authenticated}")

    plaintext = b"Dies ist eine geheime Nachricht."
    aad = "Zusätzliche Authentifizierungsdaten".encode('utf-8')
    encrypted_data = key_manager._hybrid_encrypt(plaintext, aad)
    decrypted_data = key_manager._hybrid_decrypt(encrypted_data, aad)
    print(f"Entschlüsselte Nachricht: {decrypted_data.decode()}")

    user_id = 'testuser'
    ip_address = '192.168.1.1'
    if not key_manager.rate_limit_check(user_id):
        print("Benutzer-Ratenlimit nicht überschritten")
    if not key_manager.global_rate_limit_check(ip_address):
        print("Globale Ratenlimit nicht überschritten")
